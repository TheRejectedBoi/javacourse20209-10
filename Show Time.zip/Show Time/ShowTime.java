import java.util.Calendar;
/*
	Deacon Guggenheim
	Java programming 2020
	Show Time project
	8/30/19
*/
public class ShowTime{
	
	
	
	public static void main(String[] args){
		System.out.println(Calendar.getInstance().getTime());
	}
}
